ServerEvents.recipes(event => {
  event.shapeless(Item.of('patchouli:guide_book', '{"patchouli:book":"ftbic:ftbic_guide"}'), ['minecraft:book', 'ftbic:industrial_grade_metal'])
})
