StartupEvents.registry('block', event => {
	event.create('magical_soil').displayName('§bMagical Soil').material('grass').hardness(0.6);
})